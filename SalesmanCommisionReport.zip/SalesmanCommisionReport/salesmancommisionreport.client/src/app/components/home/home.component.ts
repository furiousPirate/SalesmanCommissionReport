import { Component } from '@angular/core';
import { MenuService } from '../../services/menu.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  roles: string[] = ['Admin', 'Salesman', 'Manager'];
  selectedRole: string = '';
  roleSet: boolean = false;
  menuItems: string[] = [];

  constructor(private menuService: MenuService, private router: Router) { }

  setRole(): void {
    if (this.selectedRole) {
      localStorage.setItem('userRole', this.selectedRole);
      this.menuService.getMenuForRole(this.selectedRole).subscribe(menu => {
        this.menuItems = menu;
      });
      if (this.selectedRole != 'Admin') {
        alert("You are not allowed to see Dashboard. only Admin is allowed to")
      }
      else {
        this.router.navigate(['/car-model-management']); 
      }
    } else {
      alert('Please select a role first!');
    }
  }

}
