import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CarModel } from '../../models/models';

@Injectable({
  providedIn: 'root'
})
export class CarModalService {
  private apiUrl = 'http://localhost:5149/api/carmodels/';

  constructor(private http: HttpClient) { }
  getAllCarModels(): Observable<CarModel[]> {
  return this.http.get<CarModel[]>(this.apiUrl + 'getAllCarModels');
  }
  createCarModel(carModel: CarModel): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });
    return this.http.post(this.apiUrl + 'createCarModel', carModel, { headers });
  }
  searchCarModels(searchTerm: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}searchCarModels?searchTerm=${searchTerm}`);
  }
}
