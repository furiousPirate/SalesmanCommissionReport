import { TestBed } from '@angular/core/testing';

import { CarModalService } from './car-modal.service';

describe('CarModalService', () => {
  let service: CarModalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CarModalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
