import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private http: HttpClient) { }

  getMenuForRole(role: string): Observable<any> {
    return this.http.get<any>(`http://localhost:5149/api/menu/role?role=${role}`).pipe(
      catchError(error => {
        console.error('Error fetching menu for role:', error);
        return throwError(error);
      })
    );
  }

}
