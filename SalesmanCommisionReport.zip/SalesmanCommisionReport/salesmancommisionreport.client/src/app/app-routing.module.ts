import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { RoleGuard } from './guards/auth.guard';

const routes: Routes = [
  { path: 'car-model-management', loadChildren: () => import('./modules/management/management.module').then(m => m.ManagementModule), canActivate: [RoleGuard] },
  { path: 'salesman-commission-report', loadChildren: () => import('./modules/report/report.module').then(m => m.ReportModule), canActivate: [RoleGuard] },
  { path: 'home', component: HomeComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', redirectTo:'/home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
