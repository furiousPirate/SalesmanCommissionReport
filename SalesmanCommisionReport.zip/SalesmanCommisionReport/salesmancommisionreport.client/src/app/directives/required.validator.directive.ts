import { Directive, Input } from '@angular/core';
import { AbstractControl, ValidatorFn, NG_VALIDATORS, ValidationErrors } from '@angular/forms';

@Directive({
  selector: '[appRequired]',
  providers: [{ provide: NG_VALIDATORS, useExisting: RequiredValidatorDirective, multi: true }]
})
export class RequiredValidatorDirective {
  @Input('appRequired') required: boolean = true;

  validate(control: AbstractControl): ValidationErrors | null {
    return this.required && (control.value == null || control.value.trim() === '') ? { required: true } : null;
  }
}
