import { Pipe, PipeTransform } from '@angular/core';
import { CarModel } from '../models/models';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {
  transform(carModels: CarModel[], sortBy: string): CarModel[] {
    if (!carModels || !sortBy) return carModels;

    return carModels.sort((a, b) => {
      if (sortBy === 'dateOfManufacturing') {
        return new Date(b.dateOfManufacturing).getTime() - new Date(a.dateOfManufacturing).getTime();
      } else if (sortBy === 'sortOrder') {
        return a.sortOrder - b.sortOrder;
      }
      return 0;
    });
  }
}
