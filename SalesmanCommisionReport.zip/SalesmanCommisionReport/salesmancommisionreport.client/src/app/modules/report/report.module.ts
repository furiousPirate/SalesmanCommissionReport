import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SalesmanCommissionreportComponent } from './salesman-commissionreport/salesman-commissionreport.component';

const routes: Routes = [
  { path: '', component: SalesmanCommissionreportComponent }
];

@NgModule({
  declarations: [
    SalesmanCommissionreportComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ReportModule { }
