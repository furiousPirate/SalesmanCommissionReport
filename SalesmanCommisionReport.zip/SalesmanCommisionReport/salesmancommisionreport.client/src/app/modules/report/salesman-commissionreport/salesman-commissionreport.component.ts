import { Component, OnInit } from '@angular/core';
import { ReportServiceService } from '../../../services/reportService/report-service.service';
import { SalesmanCommissionReport } from '../../../models/models';

@Component({
  selector: 'app-salesman-commissionreport',
  templateUrl: './salesman-commissionreport.component.html',
  styleUrl: './salesman-commissionreport.component.css'
})
export class SalesmanCommissionreportComponent implements OnInit {
  report: SalesmanCommissionReport | null = null;
  loading = true;
  error: string | null = null;
  constructor(private salesmanService: ReportServiceService) { }

  ngOnInit(): void {
    this.fetchSalesmanCommissionReport();
  }
  fetchSalesmanCommissionReport(): void {
    this.salesmanService.getSalesmanCommissionReport().subscribe({
      next: (data:any) => {
        this.report = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load report';
        this.loading = false;
      }
    });
  }
}
