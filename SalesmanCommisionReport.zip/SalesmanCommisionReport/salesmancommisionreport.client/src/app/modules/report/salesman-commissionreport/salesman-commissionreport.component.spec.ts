import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesmanCommissionreportComponent } from './salesman-commissionreport.component';

describe('SalesmanCommissionreportComponent', () => {
  let component: SalesmanCommissionreportComponent;
  let fixture: ComponentFixture<SalesmanCommissionreportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SalesmanCommissionreportComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SalesmanCommissionreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
