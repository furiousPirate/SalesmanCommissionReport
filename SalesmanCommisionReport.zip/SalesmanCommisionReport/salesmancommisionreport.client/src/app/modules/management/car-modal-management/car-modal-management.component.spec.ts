import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarModalManagementComponent } from './car-modal-management.component';

describe('CarModalManagementComponent', () => {
  let component: CarModalManagementComponent;
  let fixture: ComponentFixture<CarModalManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CarModalManagementComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CarModalManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
