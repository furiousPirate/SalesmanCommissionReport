import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClassicEditor, Bold, Essentials, Italic, Mention, Paragraph, Undo } from 'ckeditor5';
import { CarModalService } from '../../../services/carModelService/car-modal.service';
import { CarModel } from '../../../models/models';

@Component({
  selector: 'app-car-modal-management',
  templateUrl: './car-modal-management.component.html',
  styleUrl: './car-modal-management.component.css'
})
export class CarModalManagementComponent implements OnInit {
  public Editor = ClassicEditor;
  public config = {
    toolbar: ['undo', 'redo', '|', 'bold', 'italic'],
    plugins: [
      Bold, Essentials, Italic, Mention, Paragraph, Undo
    ],
    placeholder: 'Type your description here...'
  }
  carModelForm!: FormGroup;
  carModels: CarModel[] = [];
  searchModel: string = '';
  sortBy: string = 'sortOrder'; 
  constructor(private fb: FormBuilder, private carModelService: CarModalService) { }
  ngOnInit(): void {

    this.carModelService.getAllCarModels().subscribe({
      next: (data) => this.carModels = data,
      error: (err) => console.error('Error fetching car models', err)
    });

    this.carModelForm = this.fb.group({
      brand: ['', [Validators.required]],
      class: ['', [Validators.required]],
      modelName: ['', [Validators.required]],
      modelCode: ['', [Validators.required, Validators.maxLength(10), Validators.pattern(/^[a-zA-Z0-9]*$/)]],
      description: ['', [Validators.required]],
      features: ['', [Validators.required]],
      price: ['', [Validators.required, Validators.min(0)]],
      dateOfManufacturing: ['', [Validators.required]],
      active: [false],
      sortOrder: ['', [Validators.required]],
      modelImages: [null]
    });
  }
  onFileChange(event: any) {
    const files = event.target.files;
    if (files) {
      const fileArray: string[] = []; 
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > 5 * 1024 * 1024) {
          alert('File size exceeds 5MB!');
          return;
        }

        const reader = new FileReader();
        reader.onload = (e: any) => {
          const base64String = e.target.result; // Get base64 string from file
          fileArray.push(base64String); 
          if (fileArray.length === files.length) {
            this.carModelForm.patchValue({ modelImages: fileArray });
          }
        };
        reader.readAsDataURL(file); // Convert file to base64
      }
    }
  }

  onSubmit() {
    if (this.carModelForm.valid) {
      const carModelData = {
        ...this.carModelForm.value
      };
      this.carModelService.createCarModel(carModelData).subscribe({
        next: (response) => {
          alert('Car model created successfully!');
          window.location.reload();
        },
        error: (error) => {
          alert('Error creating car model:');
        }
      });
    } else {
      this.carModelForm.markAllAsTouched();
    }
  }

  onSearch(): void {
    this.carModelService.searchCarModels(this.searchModel).subscribe(data => {
      this.carModels = data.result;
    });
  }
}
