import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CarModalManagementComponent } from './car-modal-management/car-modal-management.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { SortPipe } from '../../pipes/sort.pipe';



const routes: Routes = [
  { path: '', component: CarModalManagementComponent }
];

@NgModule({
  declarations: [
    CarModalManagementComponent,
    SortPipe
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    CKEditorModule    
  ],
  exports: [RouterModule]
})
export class ManagementModule { }
