export interface CarModel {
  id: number;
  brand: string;
  class: string;
  modelName: string;
  modelCode: string;
  description: string;
  features: string;
  price: number;
  dateOfManufacturing: Date;
  active: boolean;
  sortOrder: number;
  modelImages: string[];
}
export interface SalesmanCommissionReport {
  salesmen: Salesman[];
  carModels: CarModel[];
  sales: Sale[];
}

export interface Salesman {
  id: number;
  name: string;
  lastYearTotalSaleAmount: number;
}

export interface CarModel {
  id: number;
  brand: string;
  class: string;
  modelName: string;
  price: number;
}

export interface Sale {
  id: number;
  salesmanId: number;
  brand: string;
  class: string;
  numberOfCarsSold: number;
}
