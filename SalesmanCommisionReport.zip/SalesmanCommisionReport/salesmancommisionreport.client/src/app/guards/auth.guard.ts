import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(private router: Router) { }

  canActivate(): Observable<boolean> {
    const role = localStorage.getItem('userRole'); // Retrieve the role from local storage

    // Check the role and return an Observable
    return of(role).pipe(
      map(role => {
        if (role === 'Admin') {
          return true; // Allow access for admin
        } else if (role === 'salesman') {
          this.router.navigate(['/home']); // Redirect to a not-allowed page for salesman
          return false; // Block access for salesman
        }

        // Handle the case where role is null or invalid
        this.router.navigate(['/home']); // Redirect to login if no valid role is found
        return false;
      }),
      catchError(() => {
        this.router.navigate(['/home']); // Handle errors gracefully
        return of(false);
      })
    );
  }
}
