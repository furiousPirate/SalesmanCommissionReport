﻿using Microsoft.AspNetCore.Mvc;
using SalesmanCommisionReport.Server.Services;

namespace SalesmanCommisionReport.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalesmanController : ControllerBase
    {
        private readonly ISalesmanService _salesmanService;

        public SalesmanController(ISalesmanService salesmanService)
        {
            _salesmanService = salesmanService;
        }

        [HttpGet("commission-report")]
        public async Task<IActionResult> GetSalesmanCommissionReport()
        {
            var report = await _salesmanService.GetSalesmanCommissionReportAsync();
            return Ok(report);
        }
    }
}
