﻿using Microsoft.AspNetCore.Mvc;
using SalesmanCommisionReport.Server.Services;
using SalesmanCommissionReport.Server.Models;

namespace SalesmanCommisionReport.Server.Controllers
{
    [ApiController]
    [Route("api/carmodels")]
    public class CarModelController : ControllerBase
    {
        private readonly ICarModelService _carModelService;

        public CarModelController(ICarModelService carModelService)
        {
            _carModelService = carModelService;
        }

        [HttpGet("getAllCarModels")]
        public async Task<IActionResult> GetAllCarModels()
        {
            var carModels = await _carModelService.GetAllCarModelsAsync();
            return Ok(carModels);
        }
        [HttpPost("createCarModel")]
        public async Task<IActionResult> CreateCarModel([FromBody] CarModel carModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _carModelService.CreateCarModelAsync(carModel);

            return Ok(new { message = "Car Model created successfully!" });
        }

        [HttpGet("searchCarModels")]
        public IActionResult SearchCarModels(string searchTerm)
        {
            var results = _carModelService.SearchCarModelsAsync(searchTerm);

            return Ok(results);
        }
    }
}
