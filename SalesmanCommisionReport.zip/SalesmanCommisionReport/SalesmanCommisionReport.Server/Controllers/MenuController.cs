﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using SalesmanCommissionReport.Server.Services;

namespace SalesmanCommissionReport.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MenuController : ControllerBase
    {
        private readonly MenuService _menuService;
        public MenuController(MenuService menuService)  
        {
            _menuService = menuService;
        }

        [HttpGet("role")]
        public IActionResult GetMenuForRole(string role)
        {
            var menuItems = _menuService.GetMenuForRole(role);
       
            return Ok(menuItems);
        }
    }
}
