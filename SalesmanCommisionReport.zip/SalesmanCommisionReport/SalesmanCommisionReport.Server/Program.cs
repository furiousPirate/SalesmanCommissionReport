using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Cors;
using SalesmanCommisionReport.Server.ErrorHandler;
using SalesmanCommisionReport.Server.Services;
using SalesmanCommissionReport.Server.Services;

var builder = WebApplication.CreateBuilder(args);

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAllOrigins", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

// Register services
builder.Services.AddScoped<DatabaseInitializer>();
builder.Services.AddScoped<ICarModelService, CarModelService>();
builder.Services.AddScoped<ISalesmanService, SalesmanService>();
builder.Services.AddScoped<MenuService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseHttpsRedirection();
app.UseCors("AllowAllOrigins");
app.UseMiddleware<ErrorHandlingMiddleware>(); // Custom error handling middleware
app.UseAuthentication(); // Enable authentication
app.UseAuthorization();  // Enable authorization

app.MapControllers();

using (var scope = app.Services.CreateScope())
{
    var dbInitializer = scope.ServiceProvider.GetRequiredService<DatabaseInitializer>();
    await dbInitializer.InitializeAsync(); // Initialize database
}

app.MapFallbackToFile("index.html"); // Fallback to Angular's index.html

app.Run(); // Start the application
