﻿using System.ComponentModel.DataAnnotations;

namespace SalesmanCommissionReport.Server.Models
{
    public class CarModel
    {
        public int Id { get; set; }
        public required string Brand { get; set; }
        public required string Class { get; set; }
        [MaxLength(50)]
        public required string ModelName { get; set; }
        [MaxLength(10)]
        [RegularExpression(@"^[a-zA-Z0-9]+$", ErrorMessage = "Model Code must be alphanumeric")]
        public required string ModelCode { get; set; }
        public required string Description { get; set; }
        public required string Features { get; set; }
        [Range(1, 1000000)]
        public required decimal Price { get; set; }
        public required DateTime DateOfManufacturing { get; set; }
        public bool Active { get; set; }
        public int SortOrder { get; set; }
        public required List<string> ModelImages { get; set; }
    }
}
