﻿namespace SalesmanCommisionReport.Server.Models
{
    public class SalesmanCommissionReportDto
    {
        public List<SalesmanDto> Salesmen { get; set; } = new List<SalesmanDto>();
        public List<CarModelDto> CarModels { get; set; } = new List<CarModelDto>();
        public List<SaleDto> Sales { get; set; } = new List<SaleDto>();
    }

    public class SalesmanDto
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal LastYearTotalSaleAmount { get; set; }
    }

    public class CarModelDto
    {
        public int Id { get; set; }
        public string? Brand { get; set; }
        public string? Class { get; set; }
        public string? ModelName { get; set; }
        public decimal Price { get; set; }
    }

    public class SaleDto
    {
        public int Id { get; set; }
        public int SalesmanId { get; set; }
        public string? Brand { get; set; }
        public string? Class { get; set; }
        public int NumberOfCarsSold { get; set; }
    }
}
