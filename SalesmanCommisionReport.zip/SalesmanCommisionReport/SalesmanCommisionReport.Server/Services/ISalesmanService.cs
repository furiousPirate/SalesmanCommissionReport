﻿using SalesmanCommisionReport.Server.Models;

namespace SalesmanCommisionReport.Server.Services
{
    public interface ISalesmanService
    {
        Task<SalesmanCommissionReportDto> GetSalesmanCommissionReportAsync();
    }
}
