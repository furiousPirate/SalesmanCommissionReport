﻿using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;

namespace SalesmanCommisionReport.Server.Services
{
    public class DatabaseInitializer
    {
        private readonly string _connectionString;

        public DatabaseInitializer(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task InitializeAsync()
        {
            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Create tables
                await CreateTablesAsync(connection);

                // Insert sample data after tables are created
                await InsertSampleDataAsync(connection);
            }
        }

        private async Task CreateTablesAsync(SqliteConnection connection)
        {
            using (var command = connection.CreateCommand())
            {
                // Creating CarModels table if it doesn't exist
                command.CommandText = createCarModelsTable;
                await command.ExecuteNonQueryAsync();

                // Creating ModelImages table if it doesn't exist
                command.CommandText = createModelImagesTable;
                await command.ExecuteNonQueryAsync();

                // Creating Sales table if it doesn't exist
                command.CommandText = createSalesTable;
                await command.ExecuteNonQueryAsync();

                // Creating Salesman table if it doesn't exist
                command.CommandText = createSalesmanTable;
                await command.ExecuteNonQueryAsync();
            }
        }

        const string createCarModelsTable = @"
        CREATE TABLE IF NOT EXISTS CarModels (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Brand TEXT NOT NULL,
            Class TEXT NOT NULL,
            ModelName TEXT NOT NULL,
            ModelCode TEXT NOT NULL,
            Description TEXT NOT NULL,
            Features TEXT NOT NULL,
            Price REAL NOT NULL,
            DateOfManufacturing DATETIME NOT NULL,
            Active BOOLEAN NOT NULL,
            SortOrder INTEGER NOT NULL
        );";

        const string createModelImagesTable = @"
        CREATE TABLE IF NOT EXISTS ModelImages (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            CarModelId INTEGER NOT NULL,
            ImagePath TEXT NOT NULL,
            FOREIGN KEY (CarModelId) REFERENCES CarModels(Id)
        );";

        const string createSalesTable = @"
        CREATE TABLE IF NOT EXISTS Sales (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            SalesmanId INTEGER NOT NULL,
            Brand TEXT NOT NULL,
            Class TEXT NOT NULL,
            NumberOfCarsSold INTEGER NOT NULL,
            FOREIGN KEY (SalesmanId) REFERENCES Salesman(Id)
        );";

        const string createSalesmanTable = @"
        CREATE TABLE IF NOT EXISTS Salesman (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            LastYearTotalSaleAmount REAL NOT NULL
        );";

        private async Task InsertSampleDataAsync(SqliteConnection connection)
        {
            using (var command = connection.CreateCommand())
            {
                // Insert Salesman data
                command.CommandText = @"
                INSERT INTO Salesman (Name, LastYearTotalSaleAmount) VALUES
                ('John Smith', 490000),
                ('Richard Porter', 1000000),
                ('Tony Grid', 650000);";
                await command.ExecuteNonQueryAsync();

                // Insert Car Models data
                command.CommandText = @"
                INSERT INTO CarModels (Brand, Class, ModelName, ModelCode, Description, Features, Price, DateOfManufacturing, Active, SortOrder) VALUES
                ('Audi', 'A', 'Audi A4', 'A4', 'Luxury Sedan', 'Feature 1', 30000, '2020-01-01', 1, 1),
                ('Jaguar', 'B', 'Jaguar F-Pace', 'F-Pace', 'Luxury SUV', 'Feature 2', 40000, '2019-01-01', 1, 2),
                ('Land Rover', 'C', 'Land Rover Discovery', 'Discovery', 'Luxury SUV', 'Feature 3', 50000, '2018-01-01', 1, 3),
                ('Renault', 'A', 'Renault Duster', 'Duster', 'Compact SUV', 'Feature 4', 20000, '2021-01-01', 1, 4);";
                await command.ExecuteNonQueryAsync();

                // Insert Sales data
                command.CommandText = @"
                INSERT INTO Sales (SalesmanId, Brand, Class, NumberOfCarsSold) VALUES
                (1, 'Audi', 'A', 1),
                (1, 'Jaguar', 'B', 3),
                (1, 'Land Rover', 'C', 0),
                (1, 'Renault', 'A', 6),
                (2, 'Audi', 'A', 0),
                (2, 'Jaguar', 'B', 5),
                (2, 'Land Rover', 'C', 5),
                (2, 'Renault', 'A', 3),
                (3, 'Audi', 'A', 4),
                (3, 'Jaguar', 'B', 2),
                (3, 'Land Rover', 'C', 1),
                (3, 'Renault', 'A', 6);";
                await command.ExecuteNonQueryAsync();
            }
        }
    }
}
