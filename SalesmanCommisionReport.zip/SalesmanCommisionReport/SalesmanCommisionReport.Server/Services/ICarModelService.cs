﻿using SalesmanCommissionReport.Server.Models;

namespace SalesmanCommisionReport.Server.Services
{
    public interface ICarModelService
    {
        Task<IEnumerable<CarModel>> GetAllCarModelsAsync();
        Task<IEnumerable<CarModel>> SearchCarModelsAsync(string searchTerm);
        Task CreateCarModelAsync(CarModel carModel);
    }
}
