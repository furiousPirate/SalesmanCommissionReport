﻿using Microsoft.Data.Sqlite;
using SalesmanCommisionReport.Server.Models;

namespace SalesmanCommisionReport.Server.Services
{
    public class SalesmanService : ISalesmanService
    {
        private readonly string _connectionString;

        public SalesmanService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<SalesmanCommissionReportDto> GetSalesmanCommissionReportAsync()
        {
            var report = new SalesmanCommissionReportDto();
            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Fetch Salesmen data
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT Id, Name, LastYearTotalSaleAmount FROM Salesman;";
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            report.Salesmen.Add(new SalesmanDto
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                LastYearTotalSaleAmount = reader.GetDecimal(2)
                            });
                        }
                    }
                }

                // Fetch Car Models data
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT * FROM CarModels;";
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            report.CarModels.Add(new CarModelDto
                            {
                                Id = reader.GetInt32(0),
                                Brand = reader.GetString(1),
                                Class = reader.GetString(2),
                                ModelName = reader.GetString(3),
                                Price = reader.GetDecimal(7) // Adjusted index for Price
                            });
                        }
                    }
                }

                // Fetch Sales data
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT * FROM Sales;";
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            report.Sales.Add(new SaleDto
                            {
                                Id = reader.GetInt32(0),
                                SalesmanId = reader.GetInt32(1),
                                Brand = reader.GetString(2),
                                Class = reader.GetString(3),
                                NumberOfCarsSold = reader.GetInt32(4)
                            });
                        }
                    }
                }
            }
            return report; // Return the populated report
        }
    }
}
