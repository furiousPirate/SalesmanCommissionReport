﻿namespace SalesmanCommissionReport.Server.Services
{
    public class MenuService
    {
        public List<string> GetMenuForRole(string role)
        {
            var menuItems = new List<string>();

            switch (role)
            {
                case "Admin":
                    menuItems.Add("Dashboard");
                    menuItems.Add("Manage Cars");
                    menuItems.Add("Manage Salesmen");
                    break;

                case "Salesman":
                    menuItems.Add("View Cars");
                    menuItems.Add("Commission Report");
                    break;

                case "Manager":
                    menuItems.Add("Reports");
                    menuItems.Add("Sales Dashboard");
                    break;
            }

            return menuItems;
        }
    }
}
