﻿using Microsoft.Data.Sqlite;
using SalesmanCommissionReport.Server.Models;
using System.Data;

namespace SalesmanCommisionReport.Server.Services
{
    public class CarModelService : ICarModelService
    {
        private readonly string _connectionString;

        public CarModelService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        public async Task<IEnumerable<CarModel>> GetAllCarModelsAsync()
        {
            var carModels = new List<CarModel>();

            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (var command = new SqliteCommand("SELECT * FROM CarModels", connection))
                {
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var carModel = new CarModel
                            {
                                Brand = reader["Brand"].ToString(),
                                Class = reader["Class"].ToString(),
                                ModelName = reader["ModelName"].ToString(),
                                ModelCode = reader["ModelCode"].ToString(),
                                Description = reader["Description"].ToString(),
                                Features = reader["Features"].ToString(),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                DateOfManufacturing = reader.GetDateTime(reader.GetOrdinal("DateOfManufacturing")),
                                Active = reader.GetBoolean(reader.GetOrdinal("Active")),
                                SortOrder = reader.GetInt32(reader.GetOrdinal("SortOrder")),
                                ModelImages = new List<string>()
                            };
                            carModels.Add(carModel);
                        }
                    }
                }
            }
            return carModels;
        }
        public async Task CreateCarModelAsync(CarModel carModel)
        {
            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.OpenAsync();
                long carModelId = 0;
                using (var transaction = connection.BeginTransaction()) // Begin a transaction
                {
                    // Step 1: Insert into CarModels and retrieve the last inserted Id
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"
            INSERT INTO CarModels (Brand, Class, ModelName, ModelCode, Description, Features, Price, DateOfManufacturing, Active, SortOrder) 
            VALUES (@Brand, @Class, @ModelName, @ModelCode, @Description, @Features, @Price, @DateOfManufacturing, @Active, @SortOrder);
            SELECT last_insert_rowid();";  // This gets the last inserted row id in SQLite

                        // Add parameters for CarModels
                        command.Parameters.Add(new SqliteParameter("@Brand", DbType.String) { Value = carModel.Brand });
                        command.Parameters.Add(new SqliteParameter("@Class", DbType.String) { Value = carModel.Class });
                        command.Parameters.Add(new SqliteParameter("@ModelName", DbType.String) { Value = carModel.ModelName });
                        command.Parameters.Add(new SqliteParameter("@ModelCode", DbType.String) { Value = carModel.ModelCode });
                        command.Parameters.Add(new SqliteParameter("@Description", DbType.String) { Value = carModel.Description });
                        command.Parameters.Add(new SqliteParameter("@Features", DbType.String) { Value = carModel.Features });
                        command.Parameters.Add(new SqliteParameter("@Price", DbType.Decimal) { Value = carModel.Price });
                        command.Parameters.Add(new SqliteParameter("@DateOfManufacturing", DbType.DateTime) { Value = carModel.DateOfManufacturing });
                        command.Parameters.Add(new SqliteParameter("@Active", DbType.Boolean) { Value = carModel.Active });
                        command.Parameters.Add(new SqliteParameter("@SortOrder", DbType.Int32) { Value = carModel.SortOrder });

                        // Execute the insert and get the newly inserted CarModel Id
                        carModelId = (long)await command.ExecuteScalarAsync();
                    }

                    // Step 2: Insert each image with the CarModelId into ModelImages
                    foreach (var imageBase64 in carModel.ModelImages) // Assuming carModel.Images contains base64 encoded images
                    {
                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = @"
                INSERT INTO ModelImages (CarModelId, ImagePath) 
                VALUES (@CarModelId, @ImagePath)";

                            command.Parameters.Add(new SqliteParameter("@CarModelId", DbType.Int64) { Value = carModelId });
                            command.Parameters.Add(new SqliteParameter("@ImagePath", DbType.String) { Value = imageBase64 });

                            await command.ExecuteNonQueryAsync();
                        }
                    }

                    // Step 3: Commit the transaction after successful inserts
                    await transaction.CommitAsync();
                }
            }
        }

        public async Task<IEnumerable<CarModel>> SearchCarModelsAsync(string searchTerm)
        {
            var carModels = new List<CarModel>();

            using (var connection = new SqliteConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (var command = new SqliteCommand("SELECT * FROM CarModels WHERE ModelName LIKE @SearchTerm OR ModelCode LIKE @SearchTerm", connection))
                {
                    command.Parameters.AddWithValue("@SearchTerm", $"%{searchTerm}%");

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var carModel = new CarModel
                            {
                                Brand = reader["Brand"].ToString(),
                                Class = reader["Class"].ToString(),
                                ModelName = reader["ModelName"].ToString(),
                                ModelCode = reader["ModelCode"].ToString(),
                                Description = reader["Description"].ToString(),
                                Features = reader["Features"].ToString(),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                DateOfManufacturing = reader.GetDateTime(reader.GetOrdinal("DateOfManufacturing")),
                                Active = reader.GetBoolean(reader.GetOrdinal("Active")),
                                SortOrder = reader.GetInt32(reader.GetOrdinal("SortOrder")),
                                ModelImages = new List<string>() // Handle images if needed
                            };

                            carModels.Add(carModel);
                        }
                    }
                }
            }

            return carModels;
        }

    }
}
